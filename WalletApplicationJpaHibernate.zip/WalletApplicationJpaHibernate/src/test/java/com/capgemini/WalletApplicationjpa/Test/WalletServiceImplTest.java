package com.capgemini.WalletApplicationjpa.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.sql.SQLException;

import org.junit.Test;

import com.cg.WalletApplicationjpa.Exception.BankException;
import com.cg.WalletApplicationjpa.bean.Customer;
import com.cg.WalletApplicationjpa.bean.Wallet;
import com.cg.WalletApplicationjpa.service.IWalletService;
import com.cg.WalletApplicationjpa.service.WalletServiceImpl;

public class WalletServiceImplTest {
	public static IWalletService iWalletService=new WalletServiceImpl();
    @Test
	public void addCustomerTestTrue() throws BankException
	{
		Customer customer1 = new Customer("9443067189","ramnivas","Ramnivas@123","ramnivas123@gmail.com",new Wallet());
		assertEquals("9443067189",iWalletService.addCustomer(customer1));
			
	}
    @Test(expected = BankException.class)
  	public void addCustomerTestFalse() throws BankException
  	{

  		Customer customer2 = new Customer("9940509540","abcdefgh","Abcdefgh@123","abcdefgh@gmail.com",new Wallet());
  		assertNotEquals("9940509540",iWalletService.addCustomer(customer2));
  		
  	}
	

	@Test
	public void initBalanceTest() throws BankException
	{
		Customer customer8 = new Customer("9790724508","tendulkar","Tendulkar@10","tendulkar@gmail.com",new Wallet());
		assertEquals(BigDecimal.valueOf(0.0),customer8.getWallet().getBalance());
		
	}
	
	@Test
	public void depositMoneyTest() throws BankException, ClassNotFoundException, SQLException
	{
		Customer customer4 = new Customer("9940509540","abcdefgh","Abcdefgh@123","abcdefgh@gmail.com",new Wallet());
		iWalletService.addCustomer(customer4);
		iWalletService.deposit(customer4, BigDecimal.valueOf(8500.00));
		Customer result = iWalletService.showBalance("9940509540", "Abcdefgh@123");
		assertEquals(BigDecimal.valueOf(8500),result.getWallet().getBalance());
	}
	@Test(expected = BankException.class)
	public void withdrawMoneyTestTrue() throws BankException, ClassNotFoundException, SQLException
	{
		Customer customer5 = new Customer("9940509540","abcdefgh","Abcdefgh@123","abcdefgh@gmail.com",new Wallet());
		iWalletService.addCustomer(customer5);
		iWalletService.deposit(customer5, BigDecimal.valueOf(8500.00));
		assertTrue(iWalletService.withDraw(customer5, BigDecimal.valueOf(3000.00)));
	}

	
	@Test(expected = BankException.class)
	public void withdrawMoneyTestFalse() throws BankException, ClassNotFoundException, SQLException
	{
		Customer customer6 = new Customer("9940509540","abcdefgh","Abcdefgh@123","abcdefgh@gmail.com",new Wallet());
		iWalletService.addCustomer(customer6);
		iWalletService.deposit(customer6, BigDecimal.valueOf(8500.00));
		assertFalse(iWalletService.withDraw(customer6, BigDecimal.valueOf(9000.00)));
	}

}
